<?php
if($_SESSION['user_id']=='1104108')
{
	?>
	<div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
				
                    <li>
                        <a href="account.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
				   <li>
                        <a href="account.php" class=" hvr-bounce-to-right"><i class="fa fa-cog nav_icon"></i><span class="nav-label">Seek Support</span> </a>
                    </li>
					
					<li>
                        <a href="feedback.php" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon "></i><span class="nav-label"> Support Feedback</span> </a>
                    </li>
				   
				   <li>
                        <a href="improvement.php" class=" hvr-bounce-to-right"><i class="fa fa-question-circle nav_icon "></i><span class="nav-label">KB Improvement</span> </a>
                    </li>
					
					
					<li>
                        <a href="analysis.php" class=" hvr-bounce-to-right"><i class="fa fa-area-chart nav_icon"></i><span class="nav-label"> Analysis</span> </a>
                    </li>
					
					<li>
                        <a href="qahistory.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i><span class="nav-label"> Q/A History</span> </a>
                    </li>
				   
				   
				   
				   <li>
                        <a href="case_study.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i><span class="nav-label">Case Study</span> </a>
                    </li>
					
					<li>
                        <a href="case_study_analysis.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i><span class="nav-label"> Case Study Analysis</span> </a>
                    </li>

                </ul>
            </div>
			</div>
        
<?php	
}




else{
	
	
	
	
	
	?><div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                <ul class="nav" id="side-menu">
				
                    <li>
                        <a href="account.php" class=" hvr-bounce-to-right"><i class="fa fa-dashboard nav_icon "></i><span class="nav-label">Dashboards</span> </a>
                    </li>
                   
				   <li>
                        <a href="account.php" class=" hvr-bounce-to-right"><i class="fa fa-cog nav_icon"></i><span class="nav-label">Seek Support</span> </a>
                    </li>
					
					<li>
                        <a href="feedback.php" class=" hvr-bounce-to-right"><i class="fa fa-check-square-o nav_icon "></i><span class="nav-label"> Support Feedback</span> </a>
                    </li>
				   
				  
				
					
					<li>
                        <a href="qahistory.php" class=" hvr-bounce-to-right"><i class="fa fa-inbox nav_icon"></i><span class="nav-label"> Q/A History</span> </a>
                    </li>
				   

                </ul>
            </div>
			</div>
        <?php

}

?>    