<div class="copy-right"><hr>
            <p> &copy; 2017  All Rights Reserved | Dev by Maheee Noor Tayba (1104108) </p>	  <hr>  </div>  