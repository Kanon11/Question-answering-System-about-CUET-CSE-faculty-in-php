-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 24, 2017 at 12:24 PM
-- Server version: 5.5.16
-- PHP Version: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mahee`
--

-- --------------------------------------------------------

--
-- Table structure for table `case_study`
--

CREATE TABLE IF NOT EXISTS `case_study` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `case_study` varchar(10000) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `case_study`
--

INSERT INTO `case_study` (`id`, `user_id`, `case_study`) VALUES
(27, 1104108, 'I have been , @ & suffering -  from _ fever  musclepain for a few days. I also feel headache and shivering. I cant eat or sleep well. I feel like vomiting while eating. I also feel random musclepain.'),
(28, 1104108, 'I have smoking habit. For the last few days I am suffering from severe coughing. I have lost appetite for food and suffering from fever. I also feel chest pain. I also have difficulty in breathing. No medication is working till now.'),
(32, 1104108, 'I have shivering high fever for couple of days. I cant eat or sleep well. I feel like vomiting while eating. I also feel random muscle pain. A few rashes on skin is noticable. Yesterday I even had little nose bleeding. I feel too tired to do anything.'),
(33, 1104108, 'For a few days I am seldom coughing blood. There are definitive change in my bowel habits. I have lost appetite for food. As a result I am suffering from weight loss. I also have chest pain and blurred vision.');

-- --------------------------------------------------------

--
-- Table structure for table `de`
--

CREATE TABLE IF NOT EXISTS `de` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) NOT NULL,
  `attr` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `de`
--

INSERT INTO `de` (`id`, `name`, `attr`) VALUES
(1, 'malaria', 'fever/headache/musclepain'),
(2, 'normal_fever', 'fever/headache'),
(3, 'AIDS', 'weightloss/redeye/headache');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kb_id` varchar(33) NOT NULL,
  `user_id` varchar(44) NOT NULL,
  `f1` varchar(33) NOT NULL,
  `f2` varchar(44) NOT NULL,
  `f3` varchar(45) NOT NULL,
  `f4` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `kb_id`, `user_id`, `f1`, `f2`, `f3`, `f4`) VALUES
(1, '1', '1104061', '2', '5', '4', '0'),
(2, '1', '1104061', '5', '5', '5', '5'),
(3, '7', '1104061', '5', '5', '4', '4'),
(4, '7', '1104108', '5', '5', '2', '3'),
(5, '7', '1104108', '5', '2', '4', '4'),
(6, '8', '1104108', '5', '5', '2', '3'),
(7, '8', '1104108', '3', '2', '1', '5'),
(8, '5', '1104111', '2', '3', '3', '4'),
(9, '1', '1104111', '4', '2', '3', '3'),
(10, '1', '1104108', '5', '3', '4', '4'),
(11, '1', '1104108', '3', '4', '3', '4'),
(12, '39', '1104108', '2', '2', '4', '3'),
(13, '4', '1104108', '4', '4', '4', '2');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE IF NOT EXISTS `history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(33) NOT NULL,
  `kb_id` varchar(33) NOT NULL,
  `q` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `user_id`, `kb_id`, `q`) VALUES
(3, '1104061', '7', 'What is the customer care number of ambulance ?'),
(4, '1104108', '7', 'I want to know about customer care mobile number '),
(5, '1104108', '7', 'Can you please tell me a eye specialist name of the hospital ? '),
(6, '1104108', '8', 'WHere is the surgery department ?'),
(7, '1104108', '8', 'Will the hospital close on Friday ?'),
(8, '1104111', '5', 'how many eye doctors are here?\r\n'),
(9, '1104111', '1', 'which day the hospital is not working? '),
(10, '1104108', '1', 'will the hospital be open on friday?\r\n'),
(11, '1104108', '1', 'when is open hospital?'),
(12, '1104108', '39', 'paditric'),
(13, '1104108', '4', 'airambulance');

-- --------------------------------------------------------

--
-- Table structure for table `kb`
--

CREATE TABLE IF NOT EXISTS `kb` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` varchar(1000) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `feedback` varchar(1000) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=45 ;

--
-- Dumping data for table `kb`
--

INSERT INTO `kb` (`id`, `token`, `feedback`) VALUES
(1, 'close open working', 'This hospital is closed at Friday .  '),
(2, 'customer', 'Hospital Customer care Number  : +8801713377773 '),
(3, 'air-ambulance', 'We have Ambulances in different branches of our hospital including Gulshan, Uttara, Old Dhaka and Mirpur aswell as Chittagong and Sylhet. We ourselves do not have our own Air ambulance service; but patients coming from different parts of the country by air ambulance and landing in airport are brough'),
(4, 'ambulance', 'The Ambulance service at thisHospital provides emergency support to patients who require it. In order to bring patients who call for ambulance they need to provide their home address and or telephone and cellphone number to the ambulance drivers. Also, the Emergency department, customer care and '),
(5, 'eye', 'In this Hospital,the list of eye spacialists are:PROF. DR. ZAHIDUL HAQ,   PROF. DR. ABDULLAH AL SHAFI MAJUMDAR,   PROF. DR. QAMRUZZAMAN CHOWDHURY,    PROF. DR. S. A. KHAN'),
(6, 'dentist', 'Dentists of this hospital are:DR. SABRINA Q RASHID, PROF. S M KHODEJA NAHAR BEGUM,PROF. DR. TAPAN KUMAR SAHA'),
(7, 'skin', 'Skin spacilist Doctor XYZ'),
(8, 'surgery', 'Surgery Department is in front of Emergency Unit of 2nd floor'),
(11, 'long distance telephone call', 'Dial "0" for the hospital operator to assist you if needed. If you would like to bill the call to your room, dial "9" plus "1" plus the number you are calling. For international calls, dial "9" plus "011" plus the number you are calling.To reach hospital departments from inside the hospital, dial th'),
(12, 'report delivery', 'Located on 2nd floor,beside the ICU dept. Report delivery service is open from 7.30 am to 10.00 pm.This time is extended while any vital report is necessary from patientâ€™s side.\r\n '),
(13, 'imaging appointment', 'You will need an appointment for an Ultrasound, CT (Except CT scan of brain) contrast X-Ray and MRI, but you do not need an appointment for general X-rays. Please call our scheduling office at 0 2814 1522, 02 814 4400 Ext 3101, 3102 between 8 am and 9'),
(14, 'family permitted', 'We do not encourage family members to stay in the USG room. However depending on situations the sonologist may permit husband to stay in the USG room'),
(16, 'condition emergency', 'An emergency is an accident or sudden unexpected illness that needs to be treated right away or it could result in loss of life, serious medical complications or permanent disability.\r\nExamples of emergency conditions include:\r\nheart attack\r\nsevere chest pain\r\nloss of consiousness\r\nbleeding that doe'),
(17, 'emergency', 'the emergency department is at ground floor beside the report deliery desk.'),
(18, 'Gynaecology', 'The list of  gynaceology faculty members are: \r\nPROF. DR. Ishrat Jahan Lucky,\r\n Dr. Tahera Begum,\r\n PROF. S M Khodega nahar begum'),
(20, 'Consultation service', 'In out-patient department, to provide Consultation services, our Consultants are available from 7am till 9pm on weekdays (Saturday to Thursday); of course the time varies from Consultant to Consultant; in Friday as well we have few Consultants sitting their OPD. To know details as per your choice of'),
(21, 'Pharmacy', 'We have our own indoor pharmacy right beside the main entrance and Outside pharmacy beside the parking lot.'),
(22, 'Food', 'Guest Cafeteria of United Hospital is open 24 hours every day. It is located at the ground floor of the hospital. The Cafeteria offers hygienic and delicious meal options, including vegetarian choices, local and continental cuisine, salads, snacks, grills, ice-creams, milk shake, and fresh juices. F'),
(23, 'appointment', 'To make appointment for Consultation with our Consultants who sit in our Out-patient Departments, please call our hotline 10666 from any phone anywhere in the country for any investigations or procedures as well.'),
(24, 'prayer room', 'For the Male Muslims the prayer room is located at the ground floor in the hospital lobby just besides Blood Bank and for the Female at 1st floor beside the Ultrasonography wing.'),
(25, 'ATM machine', 'Dutch Bangla Bank Ltd (DBBL) & Brac Bank Ltd, ATM booths are available at Ground Floor (Lobby) beside the Pharmacy.'),
(26, 'Visiting hour', 'Visiting Hours for Cabin & Ward: 12:30pm to 02:00pm & 05:30pm to 08:30pm; for ICU & CCU: 12:30pm to 02:00pm & 05:30pm to 07:30pm'),
(27, 'Smoking', 'Smoking is strictly prohibited inside the Hospital premise'),
(28, 'brochures leaflets', 'Yes, for awareness and better understanding about hospital facilities, disease and treatment options, United Hospital provides brochures, leaflets, cards in Bangla and English and also displays festoon and banners.'),
(29, 'social media', 'To see the official Facebook page of United Hospital Ltd is please click the link https://www.facebook.com/uhlbd/'),
(30, 'Gift Shop', 'No, at present is no gift shop available inside hospital premises.'),
(31, 'home service', 'Home Service for sample collection is available for the patient; from 8:00 am to 6:00 pm (except on Friday) Areas covered under this special service are Gulshan, Banani, Baridhara, Bashundhara, Mohakhali & Cantonment.'),
(32, 'Ultra Sonogram', 'United Hospital providing Ultra Sonogram service from 8:00 am to 8:00 pm (Saturday to Thursday) & 10:00 am to 6:00 pm (only Friday)'),
(33, 'Fibroscan', 'Yes, we have Fibroscan test facility in United Hospital and the only preparation before Fibroscan test is to keep empty stomach for two hours.'),
(34, 'Liver Disease', 'To diagnosis Liver disease Fibroscan, Serum Bilurubin , SGOT SGPT, Serum Alkaline Phosphate, Gamma GT, HBsAg, Anti HBs, HCV, AFP (Alpha Fetoprotein), Ultrasonogram â€“ Hepatobiliary  System  and Stool R/E investigations are available in United Hospital.'),
(35, 'cardiology', 'currenly working doctors are:\r\n1.Prof. Dr. H.I. Lutfor Rahman Khan \r\n2. Prof. Dr. Abdullah Al Shafi Majumdar \r\n3. Prof. Dr. Md. Afzalur Rahman \r\n4. Prof. Dr. Mir Jamal Uddin \r\n5. Prof. Dr. Abdul Wadud Chowdhury	\r\n6. Dr. Mohamamd Ullah Firoze \r\n7. Dr. Abdul Momen \r\n8. Dr. Mohamamd Solaiman Tanveer '),
(37, 'Cardiac', 'We have availble doctor Dr. Khalifa Mahmud Tarik for cardiac surgery'),
(39, 'Pediatric', '1. Dr. Kazi Nausha-Un-Nabi \r\n2. Prof. Shaheen Akhter \r\n3. Dr. Muhammad Tawfique \r\n4. Prof. Dr. Ishrat Jahan Lucky '),
(40, 'Urology', '1. Prof. Dr. S. A. Khan \r\n2. Dr. Md. Jahangir Kabir \r\n3. Dr. Md. Faisal Islam'),
(41, 'Medicine', '1. Prof. Dr. Mojibur Rahman \r\n2. Dr. S. M. Arafat \r\n3. Dr. Mohiuddin Ahmed \r\n4. Dr. Md. Mahid Khan \r\n5. Dr. Nandita Pau'),
(42, 'Dermatology', '1. Prof. Dr. Md. Rokon Uddin \r\n2. Dr. Mahmud Chowdhury \r\n3. Dr. Shafique Ahmmed Khan \r\n4. Dr. Farjana Akhter '),
(43, 'Diabetes & Endocrinology', '1. Dr. Indrajit Prasad '),
(44, 'Pathology', '1. Prof. Dr. S M Khodeza Nahar Begum \r\n2. Dr. Mashud Parvez ');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(22) NOT NULL,
  `password` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `user_id`, `password`) VALUES
(1, '1104108', '12345'),
(2, '1104061', '12345'),
(3, '1104066', '121121'),
(4, '111', '121'),
(5, '1104111', '111'),
(6, 'Mahee', '123'),
(7, '1104112', '111');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
